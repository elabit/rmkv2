def main(mode):
    print(__name__ + ": " + "This is mode {mode}")


class RobotmkAgent:
    """Base class for Robotmk Agent and Special Agent"""

    pass


if __name__ == "__main__":
    main("agent")


def run_agent():
    print(__name__ + ": " + "Robotmk is starting the agent routine!")
