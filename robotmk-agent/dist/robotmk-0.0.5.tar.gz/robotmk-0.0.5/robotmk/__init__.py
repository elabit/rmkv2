"""Robot Framework test execution and result parsing for Check_MK"""
__version__ = "0.0.5"
