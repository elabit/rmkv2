import click


@click.command()
def yyyy():
    print(__name__ + ": " + "(cli specialagent): xxxx")
