from time import sleep


def run_robot():
    print(__name__ + ": " + "Robotmk is starting the robot routine!")


def run_specialagent():
    print(__name__ + ": " + "Robotmk is starting the special agent routine!")


def run_robot():
    print(__name__ + ": " + "Robotmk is starting the robot routine!")


def run_output():
    print(__name__ + ": " + "Robotmk is starting the output routine!")
    # sleep(3)
    # print checkmk agent dummy output
    print(__name__ + ": " + "<<<robotmk:sep(0)>>>")
    print(__name__ + ": " + "foobar output ")
    # touch file in temp directory
    # with open(
    #     "C:\\Users\\vagrant\\AppData\\Local\\Temp\\robotmk_output2.txt", "w"
    # ) as f:
    #     f.write("foobar output")
